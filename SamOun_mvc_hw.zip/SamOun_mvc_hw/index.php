<?php
session_start();
    include('models/m_employee.php');
    include('controllers/c_employee.php');
    include('views/template.php');