<h2>View Detail</h2>
  <ul class="list-group">
    <li class="list-group-item"></li>
</ul>